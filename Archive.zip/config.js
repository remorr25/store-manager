const config = {
  db: {
    host: "localhost",
    user: "root",
    password: "root",
    database: "nodetest",
  },
};

module.exports = config;
